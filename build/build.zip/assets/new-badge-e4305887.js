const e="/demo/images/landing/new-badge.svg";export{e as _};
