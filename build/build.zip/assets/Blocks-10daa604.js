import{r as i,b as n,x as D,c as m,d as u,f as s,g as c,e,y as C,q}from"./index-b7d2a657.js";const E="/demo/images/blocks/hero/hero-1.png",P="/demo/images/blocks/logos/hyper.svg",A={class:"grid grid-nogutter surface-section text-800"},M={class:"col-12 md:col-6 p-6 text-center md:text-left flex align-items-center"},I=e("span",{class:"block text-6xl font-bold mb-1"},"Create the screens your",-1),S=e("div",{class:"text-6xl text-primary font-bold mb-3"},"your visitors deserve to see",-1),N=e("p",{class:"mt-0 mb-4 text-700 line-height-3"},"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",-1),L=e("div",{class:"col-12 md:col-6 overflow-hidden"},[e("img",{src:E,alt:"Image",class:"md:ml-auto block md:h-full",style:{"clip-path":"polygon(8% 0, 100% 0%, 100% 100%, 0 100%)"}})],-1),O=e("div",{class:"surface-section px-4 py-8 md:px-6 lg:px-8 text-center"},[e("div",{class:"mb-3 font-bold text-2xl"},[e("span",{class:"text-900"},"One Product, "),e("span",{class:"text-blue-600"},"Many Solutions")]),e("div",{class:"text-700 text-sm mb-6"},"Ac turpis egestas maecenas pharetra convallis posuere morbi leo urna."),e("div",{class:"grid"},[e("div",{class:"col-12 md:col-4 mb-4 px-5"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-desktop text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"Built for Developers"),e("span",{class:"text-700 text-sm line-height-3"},"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.")]),e("div",{class:"col-12 md:col-4 mb-4 px-5"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-lock text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"End-to-End Encryption"),e("span",{class:"text-700 text-sm line-height-3"},"Risus nec feugiat in fermentum posuere urna nec. Posuere sollicitudin aliquam ultrices sagittis.")]),e("div",{class:"col-12 md:col-4 mb-4 px-5"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-check-circle text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"Easy to Use"),e("span",{class:"text-700 text-sm line-height-3"},"Ornare suspendisse sed nisi lacus sed viverra tellus. Neque volutpat ac tincidunt vitae semper.")]),e("div",{class:"col-12 md:col-4 mb-4 px-5"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-globe text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"Fast & Global Support"),e("span",{class:"text-700 text-sm line-height-3"},"Fermentum et sollicitudin ac orci phasellus egestas tellus rutrum tellus.")]),e("div",{class:"col-12 md:col-4 mb-4 px-5"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-github text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"Open Source"),e("span",{class:"text-700 text-sm line-height-3"},"Nec tincidunt praesent semper feugiat. Sed adipiscing diam donec adipiscing tristique risus nec feugiat. ")]),e("div",{class:"col-12 md:col-4 md:mb-4 mb-0 px-3"},[e("span",{class:"p-3 shadow-2 mb-3 inline-block surface-card",style:{"border-radius":"10px"}},[e("i",{class:"pi pi-shield text-4xl text-blue-500"})]),e("div",{class:"text-900 mb-3 font-medium"},"Trusted Securitty"),e("span",{class:"text-700 text-sm line-height-3"},"Mattis rhoncus urna neque viverra justo nec ultrices. Id cursus metus aliquam eleifend.")])])],-1),V={class:"surface-ground px-4 py-8 md:px-6 lg:px-8"},T=e("div",{class:"text-900 font-bold text-6xl mb-4 text-center"},"Pricing Plans",-1),R=e("div",{class:"text-700 text-xl mb-6 text-center line-height-3"},"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.",-1),$={class:"grid"},F={class:"col-12 lg:col-4"},U={class:"p-3 h-full"},H={class:"shadow-2 p-3 h-full flex flex-column surface-card",style:{"border-radius":"6px"}},G=e("div",{class:"text-900 font-medium text-xl mb-2"},"Basic",-1),J=e("div",{class:"text-600"},"Plan description",-1),W=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),Y=e("div",{class:"flex align-items-center"},[e("span",{class:"font-bold text-2xl text-900"},"$9"),e("span",{class:"ml-2 font-medium text-600"},"per month")],-1),z=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),K=e("ul",{class:"list-none p-0 m-0 flex-grow-1"},[e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Arcu vitae elementum")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Dui faucibus in ornare")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Morbi tincidunt augue")])],-1),Q=e("hr",{class:"mb-3 mx-0 border-top-1 border-none surface-border mt-auto"},null,-1),X={class:"col-12 lg:col-4"},Z={class:"p-3 h-full"},ee={class:"shadow-2 p-3 h-full flex flex-column surface-card",style:{"border-radius":"6px"}},se=e("div",{class:"text-900 font-medium text-xl mb-2"},"Premium",-1),te=e("div",{class:"text-600"},"Plan description",-1),ie=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),le=e("div",{class:"flex align-items-center"},[e("span",{class:"font-bold text-2xl text-900"},"$29"),e("span",{class:"ml-2 font-medium text-600"},"per month")],-1),ce=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),ne=e("ul",{class:"list-none p-0 m-0 flex-grow-1"},[e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Arcu vitae elementum")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Dui faucibus in ornare")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Morbi tincidunt augue")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Duis ultricies lacus sed")])],-1),ae=e("hr",{class:"mb-3 mx-0 border-top-1 border-none surface-border"},null,-1),oe={class:"col-12 lg:col-4"},re={class:"p-3 h-full"},de={class:"shadow-2 p-3 flex flex-column surface-card",style:{"border-radius":"6px"}},me=e("div",{class:"text-900 font-medium text-xl mb-2"},"Enterprise",-1),ue=e("div",{class:"text-600"},"Plan description",-1),pe=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),xe=e("div",{class:"flex align-items-center"},[e("span",{class:"font-bold text-2xl text-900"},"$49"),e("span",{class:"ml-2 font-medium text-600"},"per month")],-1),be=e("hr",{class:"my-3 mx-0 border-top-1 border-none surface-border"},null,-1),fe=e("ul",{class:"list-none p-0 m-0 flex-grow-1"},[e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Arcu vitae elementum")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Dui faucibus in ornare")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Morbi tincidunt augue")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Duis ultricies lacus sed")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Imperdiet proin")]),e("li",{class:"flex align-items-center mb-3"},[e("i",{class:"pi pi-check-circle text-green-500 mr-2"}),e("span",null,"Nisi scelerisque")])],-1),ve=e("hr",{class:"mb-3 mx-0 border-top-1 border-none surface-border"},null,-1),he={class:"surface-section px-4 py-8 md:px-6 lg:px-8"},ge={class:"text-700 text-center"},_e=e("div",{class:"text-blue-600 font-bold mb-3"},[e("i",{class:"pi pi-discord"}),q(" POWERED BY DISCORD")],-1),we=e("div",{class:"text-900 font-bold text-5xl mb-3"},"Join Our Design Community",-1),ye=e("div",{class:"text-700 text-2xl mb-5"},"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.",-1),ke={class:"bg-bluegray-900 text-gray-100 p-3 flex justify-content-between lg:justify-content-center align-items-center flex-wrap"},Be=e("div",{class:"font-bold mr-8"},"🔥 Hot Deals!",-1),je=e("div",{class:"align-items-center hidden lg:flex"},[e("span",{class:"line-height-3"},"Libero voluptatum atque exercitationem praesentium provident odit.")],-1),De=e("a",{class:"flex align-items-center ml-2 mr-8"},[e("a",{class:"text-white",href:"#"},[e("span",{class:"underline font-bold"},"Learn More")])],-1),Ce={class:"flex align-items-center no-underline justify-content-center border-circle text-gray-50 hover:bg-bluegray-700 cursor-pointer transition-colors transition-duration-150 p-ripple",style:{width:"2rem",height:"2rem"}},qe=e("i",{class:"pi pi-times"},null,-1),Ee=[qe],Pe={class:"surface-section px-4 py-5 md:px-6 lg:px-8"},Ae=e("ul",{class:"list-none p-0 m-0 flex align-items-center font-medium mb-3"},[e("li",null,[e("a",{class:"text-500 no-underline line-height-3 cursor-pointer"},"Application")]),e("li",{class:"px-2"},[e("i",{class:"pi pi-angle-right text-500 line-height-3"})]),e("li",null,[e("span",{class:"text-900 line-height-3"},"Analytics")])],-1),Me={class:"flex align-items-start flex-column lg:justify-content-between lg:flex-row"},Ie=e("div",null,[e("div",{class:"font-medium text-3xl text-900"},"Customers"),e("div",{class:"flex align-items-center text-700 flex-wrap"},[e("div",{class:"mr-5 flex align-items-center mt-3"},[e("i",{class:"pi pi-users mr-2"}),e("span",null,"332 Active Users")]),e("div",{class:"mr-5 flex align-items-center mt-3"},[e("i",{class:"pi pi-globe mr-2"}),e("span",null,"9402 Sessions")]),e("div",{class:"flex align-items-center mt-3"},[e("i",{class:"pi pi-clock mr-2"}),e("span",null,"2.32m Avg. Duration")])])],-1),Se={class:"mt-3 lg:mt-0"},Ne=e("div",{class:"surface-ground px-4 py-5 md:px-6 lg:px-8"},[e("div",{class:"grid"},[e("div",{class:"col-12 md:col-6 lg:col-3"},[e("div",{class:"surface-card shadow-2 p-3 border-round"},[e("div",{class:"flex justify-content-between mb-3"},[e("div",null,[e("span",{class:"block text-500 font-medium mb-3"},"Orders"),e("div",{class:"text-900 font-medium text-xl"},"152")]),e("div",{class:"flex align-items-center justify-content-center bg-blue-100 border-round",style:{width:"2.5rem",height:"2.5rem"}},[e("i",{class:"pi pi-shopping-cart text-blue-500 text-xl"})])]),e("span",{class:"text-green-500 font-medium"},"24 new "),e("span",{class:"text-500"},"since last visit")])]),e("div",{class:"col-12 md:col-6 lg:col-3"},[e("div",{class:"surface-card shadow-2 p-3 border-round"},[e("div",{class:"flex justify-content-between mb-3"},[e("div",null,[e("span",{class:"block text-500 font-medium mb-3"},"Revenue"),e("div",{class:"text-900 font-medium text-xl"},"$2.100")]),e("div",{class:"flex align-items-center justify-content-center bg-orange-100 border-round",style:{width:"2.5rem",height:"2.5rem"}},[e("i",{class:"pi pi-map-marker text-orange-500 text-xl"})])]),e("span",{class:"text-green-500 font-medium"},"%52+ "),e("span",{class:"text-500"},"since last week")])]),e("div",{class:"col-12 md:col-6 lg:col-3"},[e("div",{class:"surface-card shadow-2 p-3 border-round"},[e("div",{class:"flex justify-content-between mb-3"},[e("div",null,[e("span",{class:"block text-500 font-medium mb-3"},"Customers"),e("div",{class:"text-900 font-medium text-xl"},"28441")]),e("div",{class:"flex align-items-center justify-content-center bg-cyan-100 border-round",style:{width:"2.5rem",height:"2.5rem"}},[e("i",{class:"pi pi-inbox text-cyan-500 text-xl"})])]),e("span",{class:"text-green-500 font-medium"},"520 "),e("span",{class:"text-500"},"newly registered")])]),e("div",{class:"col-12 md:col-6 lg:col-3"},[e("div",{class:"surface-card shadow-2 p-3 border-round"},[e("div",{class:"flex justify-content-between mb-3"},[e("div",null,[e("span",{class:"block text-500 font-medium mb-3"},"Comments"),e("div",{class:"text-900 font-medium text-xl"},"152 Unread")]),e("div",{class:"flex align-items-center justify-content-center bg-purple-100 border-round",style:{width:"2.5rem",height:"2.5rem"}},[e("i",{class:"pi pi-comment text-purple-500 text-xl"})])]),e("span",{class:"text-green-500 font-medium"},"85 "),e("span",{class:"text-500"},"responded")])])])],-1),Le={class:"surface-card p-4 shadow-2 border-round w-full lg:w-6"},Oe=e("div",{class:"text-center mb-5"},[e("img",{src:P,alt:"Image",height:"50",class:"mb-3"}),e("div",{class:"text-900 text-3xl font-medium mb-3"},"Welcome Back"),e("span",{class:"text-600 font-medium line-height-3"},"Don't have an account?"),e("a",{class:"font-medium no-underline ml-2 text-blue-500 cursor-pointer"},"Create today!")],-1),Ve=e("label",{for:"email1",class:"block text-900 font-medium mb-2"},"Email",-1),Te=e("label",{for:"password1",class:"block text-900 font-medium mb-2"},"Password",-1),Re={class:"flex align-items-center justify-content-between mb-6"},$e={class:"flex align-items-center"},Fe=e("label",{for:"rememberme1"},"Remember me",-1),Ue=e("a",{class:"font-medium no-underline ml-2 text-blue-500 text-right cursor-pointer"},"Forgot password?",-1),He={class:"surface-section"},Ge=e("div",{class:"font-medium text-3xl text-900 mb-3"},"Movie Information",-1),Je=e("div",{class:"text-500 mb-5"},"Morbi tristique blandit turpis. In viverra ligula id nulla hendrerit rutrum.",-1),We={class:"list-none p-0 m-0"},Ye={class:"flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap"},ze=e("div",{class:"text-500 w-6 md:w-2 font-medium"},"Title",-1),Ke=e("div",{class:"text-900 w-full md:w-8 md:flex-order-0 flex-order-1"},"Heat",-1),Qe={class:"w-6 md:w-2 flex justify-content-end"},Xe={class:"flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap"},Ze=e("div",{class:"text-500 w-6 md:w-2 font-medium"},"Genre",-1),es={class:"text-900 w-full md:w-8 md:flex-order-0 flex-order-1"},ss={class:"w-6 md:w-2 flex justify-content-end"},ts={class:"flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap"},is=e("div",{class:"text-500 w-6 md:w-2 font-medium"},"Director",-1),ls=e("div",{class:"text-900 w-full md:w-8 md:flex-order-0 flex-order-1"},"Michael Mann",-1),cs={class:"w-6 md:w-2 flex justify-content-end"},ns={class:"flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap"},as=e("div",{class:"text-500 w-6 md:w-2 font-medium"},"Actors",-1),os=e("div",{class:"text-900 w-full md:w-8 md:flex-order-0 flex-order-1"},"Robert De Niro, Al Pacino",-1),rs={class:"w-6 md:w-2 flex justify-content-end"},ds={class:"flex align-items-center py-3 px-2 border-top-1 border-bottom-1 surface-border flex-wrap"},ms=e("div",{class:"text-500 w-6 md:w-2 font-medium"},"Plot",-1),us=e("div",{class:"text-900 w-full md:w-8 md:flex-order-0 flex-order-1 line-height-3"},"A group of professional bank robbers start to feel the heat from police when they unknowingly leave a clue at their latest heist.",-1),ps={class:"w-6 md:w-2 flex justify-content-end"},xs=e("div",{class:"surface-card p-4 shadow-2 border-round"},[e("div",{class:"text-3xl font-medium text-900 mb-3"},"Card Title"),e("div",{class:"font-medium text-500 mb-3"},"Vivamus id nisl interdum, blandit augue sit amet, eleifend mi."),e("div",{style:{height:"150px"},class:"border-2 border-dashed surface-border"})],-1),hs={__name:"Blocks",setup(bs){const p=i(`<div class="grid grid-nogutter surface-section text-800">
    <div class="col-12 md:col-6 p-6 text-center md:text-left flex align-items-center ">
        <section>
            <span class="block text-6xl font-bold mb-1">Create the screens your</span>
            <div class="text-6xl text-primary font-bold mb-3">your visitors deserve to see</div>
            <p class="mt-0 mb-4 text-700 line-height-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

            <Button label="Learn More" type="button" class="mr-3 p-button-raised"></Button>
            <Button label="Live Demo" type="button" class="p-button-outlined"></Button>
        </section>
    </div>
    <div class="col-12 md:col-6 overflow-hidden">
        <img src="/demo/images/blocks/hero/hero-1.png" alt="Image" class="md:ml-auto block md:h-full" style="clip-path: polygon(8% 0, 100% 0%, 100% 100%, 0 100%)">
    </div>
</div>`),x=i(`<div class="surface-section px-4 py-8 md:px-6 lg:px-8 text-center">
    <div class="mb-3 font-bold text-2xl">
        <span class="text-900">One Product, </span>
        <span class="text-blue-600">Many Solutions</span>
    </div>
    <div class="text-700 text-sm mb-6">Ac turpis egestas maecenas pharetra convallis posuere morbi leo urna.</div>
    <div class="grid">
        <div class="col-12 md:col-4 mb-4 px-5">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-desktop text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">Built for Developers</div>
            <span class="text-700 text-sm line-height-3">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span>
        </div>
        <div class="col-12 md:col-4 mb-4 px-5">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-lock text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">End-to-End Encryption</div>
            <span class="text-700 text-sm line-height-3">Risus nec feugiat in fermentum posuere urna nec. Posuere sollicitudin aliquam ultrices sagittis.</span>
        </div>
        <div class="col-12 md:col-4 mb-4 px-5">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-check-circle text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">Easy to Use</div>
            <span class="text-700 text-sm line-height-3">Ornare suspendisse sed nisi lacus sed viverra tellus. Neque volutpat ac tincidunt vitae semper.</span>
        </div>
        <div class="col-12 md:col-4 mb-4 px-5">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-globe text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">Fast & Global Support</div>
            <span class="text-700 text-sm line-height-3">Fermentum et sollicitudin ac orci phasellus egestas tellus rutrum tellus.</span>
        </div>
        <div class="col-12 md:col-4 mb-4 px-5">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-github text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">Open Source</div>
            <span class="text-700 text-sm line-height-3">Nec tincidunt praesent semper feugiat. Sed adipiscing diam donec adipiscing tristique risus nec feugiat. </span>
        </div>
        <div class="col-12 md:col-4 md:mb-4 mb-0 px-3">
            <span class="p-3 shadow-2 mb-3 inline-block surface-card" style="border-radius: 10px">
                <i class="pi pi-shield text-4xl text-blue-500"></i>
            </span>
            <div class="text-900 mb-3 font-medium">Trusted Securitty</div>
            <span class="text-700 text-sm line-height-3">Mattis rhoncus urna neque viverra justo nec ultrices. Id cursus metus aliquam eleifend.</span>
        </div>
    </div>
</div>`),b=i(`<div class="surface-ground px-4 py-8 md:px-6 lg:px-8">
    <div class="text-900 font-bold text-6xl mb-4 text-center">Pricing Plans</div>
    <div class="text-700 text-xl mb-6 text-center line-height-3">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.</div>

    <div class="grid">
        <div class="col-12 lg:col-4">
            <div class="p-3 h-full">
                <div class="shadow-2 p-3 h-full flex flex-column surface-card" style="border-radius: 6px">
                    <div class="text-900 font-medium text-xl mb-2">Basic</div>
                    <div class="text-600">Plan description</div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <div class="flex align-items-center">
                        <span class="font-bold text-2xl text-900">$9</span>
                        <span class="ml-2 font-medium text-600">per month</span>
                    </div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <ul class="list-none p-0 m-0 flex-grow-1">
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Arcu vitae elementum</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Dui faucibus in ornare</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Morbi tincidunt augue</span>
                        </li>
                    </ul>
                    <hr class="mb-3 mx-0 border-top-1 border-none surface-border mt-auto" />
                    <Button label="Buy Now" class="p-3 w-full mt-auto"></Button>
                </div>
            </div>
        </div>

        <div class="col-12 lg:col-4">
            <div class="p-3 h-full">
                <div class="shadow-2 p-3 h-full flex flex-column surface-card" style="border-radius: 6px">
                    <div class="text-900 font-medium text-xl mb-2">Premium</div>
                    <div class="text-600">Plan description</div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <div class="flex align-items-center">
                        <span class="font-bold text-2xl text-900">$29</span>
                        <span class="ml-2 font-medium text-600">per month</span>
                    </div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <ul class="list-none p-0 m-0 flex-grow-1">
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Arcu vitae elementum</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Dui faucibus in ornare</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Morbi tincidunt augue</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Duis ultricies lacus sed</span>
                        </li>
                    </ul>
                    <hr class="mb-3 mx-0 border-top-1 border-none surface-border" />
                    <Button label="Buy Now" class="p-3 w-full"></Button>
                </div>
            </div>
        </div>

        <div class="col-12 lg:col-4">
            <div class="p-3 h-full">
                <div class="shadow-2 p-3 flex flex-column surface-card" style="border-radius: 6px">
                    <div class="text-900 font-medium text-xl mb-2">Enterprise</div>
                    <div class="text-600">Plan description</div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <div class="flex align-items-center">
                        <span class="font-bold text-2xl text-900">$49</span>
                        <span class="ml-2 font-medium text-600">per month</span>
                    </div>
                    <hr class="my-3 mx-0 border-top-1 border-none surface-border" />
                    <ul class="list-none p-0 m-0 flex-grow-1">
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Arcu vitae elementum</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Dui faucibus in ornare</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Morbi tincidunt augue</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Duis ultricies lacus sed</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Imperdiet proin</span>
                        </li>
                        <li class="flex align-items-center mb-3">
                            <i class="pi pi-check-circle text-green-500 mr-2"></i>
                            <span>Nisi scelerisque</span>
                        </li>
                    </ul>
                    <hr class="mb-3 mx-0 border-top-1 border-none surface-border" />
                    <Button label="Buy Now" class="p-3 w-full p-button-outlined"></Button>
                </div>
            </div>
        </div>
    </div>
</div>`),f=i(`<div class="surface-section px-4 py-8 md:px-6 lg:px-8">
    <div class="text-700 text-center">
        <div class="text-blue-600 font-bold mb-3"><i class="pi pi-discord"></i>&nbsp;POWERED BY DISCORD</div>
        <div class="text-900 font-bold text-5xl mb-3">Join Our Design Community</div>
        <div class="text-700 text-2xl mb-5">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.</div>
        <Button label="Join Now" icon="pi pi-discord" class="font-bold px-5 py-3 p-button-raised p-button-rounded white-space-nowrap"></Button>
    </div>
</div>`),v=i(`<div class="bg-bluegray-900 text-gray-100 p-3 flex justify-content-between lg:justify-content-center align-items-center flex-wrap">
    <div class="font-bold mr-8">🔥 Hot Deals!</div>
    <div class="align-items-center hidden lg:flex">
        <span class="line-height-3">Libero voluptatum atque exercitationem praesentium provident odit.</span>
    </div>
    <a class="flex align-items-center ml-2 mr-8">
        <a class="text-white" href="#"><span class="underline font-bold">Learn More</span></a>
    </a>
    <a v-ripple class="flex align-items-center no-underline justify-content-center border-circle text-gray-50 hover:bg-bluegray-700 cursor-pointer transition-colors transition-duration-150 p-ripple" style="width:2rem; height: 2rem">
        <i class="pi pi-times"></i>
    </a>
</div>`),h=i(`<div class="surface-section px-4 py-5 md:px-6 lg:px-8">
    <ul class="list-none p-0 m-0 flex align-items-center font-medium mb-3">
        <li>
            <a class="text-500 no-underline line-height-3 cursor-pointer">Application</a>
        </li>
        <li class="px-2">
            <i class="pi pi-angle-right text-500 line-height-3"></i>
        </li>
        <li>
            <span class="text-900 line-height-3">Analytics</span>
        </li>
    </ul>
    <div class="flex align-items-start flex-column lg:justify-content-between lg:flex-row">
        <div>
            <div class="font-medium text-3xl text-900">Customers</div>
            <div class="flex align-items-center text-700 flex-wrap">
                <div class="mr-5 flex align-items-center mt-3">
                    <i class="pi pi-users mr-2"></i>
                    <span>332 Active Users</span>
                </div>
                <div class="mr-5 flex align-items-center mt-3">
                    <i class="pi pi-globe mr-2"></i>
                    <span>9402 Sessions</span>
                </div>
                <div class="flex align-items-center mt-3">
                    <i class="pi pi-clock mr-2"></i>
                    <span>2.32m Avg. Duration</span>
                </div>
            </div>
        </div>
        <div class="mt-3 lg:mt-0">
            <Button label="Add" class="p-button-outlined mr-2" icon="pi pi-user-plus"></Button>
            <Button label="Save" icon="pi pi-check"></Button>
        </div>
    </div>
</div>`),g=i(`<div class="surface-ground px-4 py-5 md:px-6 lg:px-8">
    <div class="grid">
        <div class="col-12 md:col-6 lg:col-3">
            <div class="surface-card shadow-2 p-3 border-round">
                <div class="flex justify-content-between mb-3">
                    <div>
                        <span class="block text-500 font-medium mb-3">Orders</span>
                        <div class="text-900 font-medium text-xl">152</div>
                    </div>
                    <div class="flex align-items-center justify-content-center bg-blue-100 border-round" style="width:2.5rem;height:2.5rem">
                        <i class="pi pi-shopping-cart text-blue-500 text-xl"></i>
                    </div>
                </div>
                <span class="text-green-500 font-medium">24 new </span>
                <span class="text-500">since last visit</span>
            </div>
        </div>
        <div class="col-12 md:col-6 lg:col-3">
            <div class="surface-card shadow-2 p-3 border-round">
                <div class="flex justify-content-between mb-3">
                    <div>
                        <span class="block text-500 font-medium mb-3">Revenue</span>
                        <div class="text-900 font-medium text-xl">$2.100</div>
                    </div>
                    <div class="flex align-items-center justify-content-center bg-orange-100 border-round" style="width:2.5rem;height:2.5rem">
                        <i class="pi pi-map-marker text-orange-500 text-xl"></i>
                    </div>
                </div>
                <span class="text-green-500 font-medium">%52+ </span>
                <span class="text-500">since last week</span>
            </div>
        </div>
        <div class="col-12 md:col-6 lg:col-3">
            <div class="surface-card shadow-2 p-3 border-round">
                <div class="flex justify-content-between mb-3">
                    <div>
                        <span class="block text-500 font-medium mb-3">Customers</span>
                        <div class="text-900 font-medium text-xl">28441</div>
                    </div>
                    <div class="flex align-items-center justify-content-center bg-cyan-100 border-round" style="width:2.5rem;height:2.5rem">
                        <i class="pi pi-inbox text-cyan-500 text-xl"></i>
                    </div>
                </div>
                <span class="text-green-500 font-medium">520  </span>
                <span class="text-500">newly registered</span>
            </div>
        </div>
        <div class="col-12 md:col-6 lg:col-3">
            <div class="surface-card shadow-2 p-3 border-round">
                <div class="flex justify-content-between mb-3">
                    <div>
                        <span class="block text-500 font-medium mb-3">Comments</span>
                        <div class="text-900 font-medium text-xl">152 Unread</div>
                    </div>
                    <div class="flex align-items-center justify-content-center bg-purple-100 border-round" style="width:2.5rem;height:2.5rem">
                        <i class="pi pi-comment text-purple-500 text-xl"></i>
                    </div>
                </div>
                <span class="text-green-500 font-medium">85 </span>
                <span class="text-500">responded</span>
            </div>
        </div>
    </div>
</div>`),_=i(`<div class="surface-card p-4 shadow-2 border-round w-full lg:w-6">
    <div class="text-center mb-5">
        <img src="/demo/images/blocks/logos/hyper.svg" alt="Image" height="50" class="mb-3">
        <div class="text-900 text-3xl font-medium mb-3">Welcome Back</div>
        <span class="text-600 font-medium line-height-3">Don't have an account?</span>
        <a class="font-medium no-underline ml-2 text-blue-500 cursor-pointer">Create today!</a>
    </div>

    <div>
        <label for="email1" class="block text-900 font-medium mb-2">Email</label>
        <InputText id="email1" type="text" class="w-full mb-3" />

        <label for="password1" class="block text-900 font-medium mb-2">Password</label>
        <InputText id="password1" type="password" class="w-full mb-3" />

        <div class="flex align-items-center justify-content-between mb-6">
            <div class="flex align-items-center">
                <Checkbox id="rememberme1" :binary="true" v-model="checked" class="mr-2"></Checkbox>
                <label for="rememberme1">Remember me</label>
            </div>
            <a class="font-medium no-underline ml-2 text-blue-500 text-right cursor-pointer">Forgot password?</a>
        </div>

        <Button label="Sign In" icon="pi pi-user" class="w-full"></Button>
    </div>
</div>`),w=i(`<div class="surface-section">
    <div class="font-medium text-3xl text-900 mb-3">Movie Information</div>
    <div class="text-500 mb-5">Morbi tristique blandit turpis. In viverra ligula id nulla hendrerit rutrum.</div>
    <ul class="list-none p-0 m-0">
        <li class="flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap">
            <div class="text-500 w-6 md:w-2 font-medium">Title</div>
            <div class="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Heat</div>
            <div class="w-6 md:w-2 flex justify-content-end">
                <Button label="Edit" icon="pi pi-pencil" class="p-button-text"></Button>
            </div>
        </li>
        <li class="flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap">
            <div class="text-500 w-6 md:w-2 font-medium">Genre</div>
            <div class="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">
                <Chip label="Crime" class="mr-2"></Chip>
                <Chip label="Drama" class="mr-2"></Chip>
                <Chip label="Thriller"></Chip>
            </div>
            <div class="w-6 md:w-2 flex justify-content-end">
                <Button label="Edit" icon="pi pi-pencil" class="p-button-text"></Button>
            </div>
        </li>
        <li class="flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap">
            <div class="text-500 w-6 md:w-2 font-medium">Director</div>
            <div class="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Michael Mann</div>
            <div class="w-6 md:w-2 flex justify-content-end">
                <Button label="Edit" icon="pi pi-pencil" class="p-button-text"></Button>
            </div>
        </li>
        <li class="flex align-items-center py-3 px-2 border-top-1 surface-border flex-wrap">
            <div class="text-500 w-6 md:w-2 font-medium">Actors</div>
            <div class="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Robert De Niro, Al Pacino</div>
            <div class="w-6 md:w-2 flex justify-content-end">
                <Button label="Edit" icon="pi pi-pencil" class="p-button-text"></Button>
            </div>
        </li>
        <li class="flex align-items-center py-3 px-2 border-top-1 border-bottom-1 surface-border flex-wrap">
            <div class="text-500 w-6 md:w-2 font-medium">Plot</div>
            <div class="text-900 w-full md:w-8 md:flex-order-0 flex-order-1 line-height-3">
                A group of professional bank robbers start to feel the heat from police
                when they unknowingly leave a clue at their latest heist.</div>
            <div class="w-6 md:w-2 flex justify-content-end">
                <Button label="Edit" icon="pi pi-pencil" class="p-button-text"></Button>
            </div>
        </li>
    </ul>
</div>`),y=i(`<div class="surface-card p-4 shadow-2 border-round">
    <div class="text-3xl font-medium text-900 mb-3">Card Title</div>
    <div class="font-medium text-500 mb-3">Vivamus id nisl interdum, blandit augue sit amet, eleifend mi.</div>
    <div style="height: 150px" class="border-2 border-dashed surface-border"></div>
</div>`),o=i(!1);return(fs,r)=>{const t=n("Button"),l=n("BlockViewer"),d=n("InputText"),k=n("Checkbox"),a=n("Chip"),B=D("ripple");return m(),u("div",null,[s(l,{header:"Hero",code:p.value},{default:c(()=>[e("div",A,[e("div",M,[e("section",null,[I,S,N,s(t,{label:"Learn More",type:"button",class:"mr-3 p-button-raised"}),s(t,{label:"Live Demo",type:"button",class:"p-button-outlined"})])]),L])]),_:1},8,["code"]),s(l,{header:"Feature",code:x.value},{default:c(()=>[O]),_:1},8,["code"]),s(l,{header:"Pricing",code:b.value},{default:c(()=>[e("div",V,[T,R,e("div",$,[e("div",F,[e("div",U,[e("div",H,[G,J,W,Y,z,K,Q,s(t,{label:"Buy Now",class:"p-3 w-full mt-auto"})])])]),e("div",X,[e("div",Z,[e("div",ee,[se,te,ie,le,ce,ne,ae,s(t,{label:"Buy Now",class:"p-3 w-full"})])])]),e("div",oe,[e("div",re,[e("div",de,[me,ue,pe,xe,be,fe,ve,s(t,{label:"Buy Now",class:"p-3 w-full p-button-outlined"})])])])])])]),_:1},8,["code"]),s(l,{header:"Call to Action",code:f.value},{default:c(()=>[e("div",he,[e("div",ge,[_e,we,ye,s(t,{label:"Join Now",icon:"pi pi-discord",class:"font-bold px-5 py-3 p-button-raised p-button-rounded white-space-nowrap"})])])]),_:1},8,["code"]),s(l,{header:"Banner",code:v.value,containerClass:"surface-section py-8"},{default:c(()=>[e("div",ke,[Be,je,De,C((m(),u("a",Ce,Ee)),[[B]])])]),_:1},8,["code"]),s(l,{header:"Page Heading",code:h.value},{default:c(()=>[e("div",Pe,[Ae,e("div",Me,[Ie,e("div",Se,[s(t,{label:"Add",class:"p-button-outlined mr-2",icon:"pi pi-user-plus"}),s(t,{label:"Save",icon:"pi pi-check"})])])])]),_:1},8,["code"]),s(l,{header:"Stats",code:g.value},{default:c(()=>[Ne]),_:1},8,["code"]),s(l,{header:"Sign-In",code:_.value,containerClass:"surface-ground px-4 py-8 md:px-6 lg:px-8 flex align-items-center justify-content-center"},{default:c(()=>[e("div",Le,[Oe,e("div",null,[Ve,s(d,{id:"email1",type:"text",class:"w-full mb-3"}),Te,s(d,{id:"password1",type:"password",class:"w-full mb-3"}),e("div",Re,[e("div",$e,[s(k,{id:"rememberme1",binary:!0,modelValue:o.value,"onUpdate:modelValue":r[0]||(r[0]=j=>o.value=j),class:"mr-2"},null,8,["modelValue"]),Fe]),Ue]),s(t,{label:"Sign In",icon:"pi pi-user",class:"w-full"})])])]),_:1},8,["code"]),s(l,{header:"Description List",code:w.value,containerClass:"surface-section px-4 py-8 md:px-6 lg:px-8"},{default:c(()=>[e("div",He,[Ge,Je,e("ul",We,[e("li",Ye,[ze,Ke,e("div",Qe,[s(t,{label:"Edit",icon:"pi pi-pencil",class:"p-button-text"})])]),e("li",Xe,[Ze,e("div",es,[s(a,{label:"Crime",class:"mr-2"}),s(a,{label:"Drama",class:"mr-2"}),s(a,{label:"Thriller"})]),e("div",ss,[s(t,{label:"Edit",icon:"pi pi-pencil",class:"p-button-text"})])]),e("li",ts,[is,ls,e("div",cs,[s(t,{label:"Edit",icon:"pi pi-pencil",class:"p-button-text"})])]),e("li",ns,[as,os,e("div",rs,[s(t,{label:"Edit",icon:"pi pi-pencil",class:"p-button-text"})])]),e("li",ds,[ms,us,e("div",ps,[s(t,{label:"Edit",icon:"pi pi-pencil",class:"p-button-text"})])])])])]),_:1},8,["code"]),s(l,{header:"Card",code:y.value,containerClass:"px-4 py-8 md:px-6 lg:px-8"},{default:c(()=>[xs]),_:1},8,["code"])])}}};export{hs as default};
