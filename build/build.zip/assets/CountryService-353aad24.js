class n{getCountries(){return fetch("demo/data/countries.json").then(e=>e.json()).then(e=>e.data)}}export{n as C};
